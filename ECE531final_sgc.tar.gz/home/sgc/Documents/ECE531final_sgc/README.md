#  ECE-531 FINAL PROJECT
## Installing
Download the .zip file and install it on a host with buildroot
## Running
enter the directory /ECE531final_sgc and set the project.sh file to executable:
```
$ chmod +x project.sh
```
then run the build root image:
```
$ ./project.sh
```
next, login with the credentials found in the included file credentials.txt.
Once in the user's home directory in the buildroot image, you can execute the iot curl client with the following command.  Adding the '-h' switch will show the options for use.

You can log in directly to the image if the process was run in the foreground, or you can log in via ssh through the host computer on port 2222:
```
$ ssh -p 2222 'username'@localhost
```
to run the command with help:
```
./hw_arm -h
```
An valid example use would be:
```
./hw_arm -g -u www.google.com
```
The command above should return a response from google.
 
## Exiting
To shut down the client log the current user out with 'exit'.  From the login prompt enter 'Ctrl-C' to shut down the QEMU process.
